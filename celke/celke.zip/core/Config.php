<?php
session_start();
ob_start();

define('URL', 'http://localhost/celke/');
define('URLADM', 'http://localhost/celke/adm/');

define('CONTROLER', 'Home');
define('METODO', 'index');

//Credenciais de acesso ao BD
define('HOST', 'localhost');
define('USER', 'id10839407_celke_2019');
define('PASS', '19deoutubro');
define('DBNAME', 'id10839407_celke');
