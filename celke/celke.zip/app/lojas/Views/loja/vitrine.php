<?php

if (!defined('URL')) {
    header("Location: /");
    exit();
}


?>