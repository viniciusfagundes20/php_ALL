<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Celke</title>
        <link rel="icon" href="<?php echo URL; ?>assets/imagens/icone/favicon.ico">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo URL; ?>assets/css/ionicons.min.css">
        <link rel="stylesheet" href="<?php echo URL; ?>assets/css/personalizado.css">
    </head>
    <body>