<?php

namespace teste\models;

class home{

    function index(){
       echo "hello world";
    }

}


?>