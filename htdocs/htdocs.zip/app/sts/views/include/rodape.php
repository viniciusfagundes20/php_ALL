<br><br><br>
    
    <?php foreach ($js as $value) { ?>
        <script src="<?= URL."assets/js/".$value ?>"></script>
    <?php } ?>
    <footer class="footer bg-danger" style="margin-top: 60px !important;">
        <div class="container text-center">
           © copyright Vanusa Fagundes
        </div>
    </footer>    
    </body>
</html>
